import React from 'react'
import { StarIcon } from 'lucide-react'

const ReviewItem = ({ review }) => {
    return (
        <div className="bg-white shadow-sm rounded-lg p-4">
            <div className="flex items-center mb-2">
                <div className="flex mr-2">
                    {[...Array(5)].map((_, i) => (
                        <StarIcon
                            key={i}
                            className={`h-5 w-5 ${i < review.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                        />
                    ))}
                </div>
                <span className="font-semibold">{review.isAnonymous ? 'Anonymous' : review.name}</span>
            </div>
            <p className="text-gray-600">{review.comment}</p>
        </div>
    )
}

export default ReviewItem
