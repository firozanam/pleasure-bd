'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { useToast } from '@/components/ui/toast-context'
import { StarIcon } from 'lucide-react'

export default function ReviewForm({ productId }) {
    const [rating, setRating] = useState(5)
    const [comment, setComment] = useState('')
    const [name, setName] = useState('')
    const [isAnonymous, setIsAnonymous] = useState(false)
    const [isSubmitting, setIsSubmitting] = useState(false)
    const { data: session } = useSession()
    const router = useRouter()
    const { toast } = useToast()

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!session) {
            toast({
                title: "Error",
                description: "You must be signed in to leave a review",
                variant: "destructive",
            })
            return
        }

        if (rating === 0) {
            toast({
                title: "Error",
                description: "Please select a rating",
                variant: "destructive",
            })
            return
        }

        setIsSubmitting(true)
        try {
            const response = await fetch(`/api/products/${productId}/reviews`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    rating, 
                    comment, 
                    name: isAnonymous ? 'Anonymous' : (name || session.user.name),
                    isAnonymous 
                }),
            })

            if (!response.ok) {
                throw new Error('Failed to submit review')
            }

            const data = await response.json()
            toast({
                title: "Success",
                description: "Your review has been submitted",
            })
            setRating(5)
            setComment('')
            setName('')
            setIsAnonymous(false)
            router.push(`/products/${productId}`)
        } catch (error) {
            console.error('Error submitting review:', error)
            toast({
                title: "Error",
                description: "Failed to submit review. Please try again.",
                variant: "destructive",
            })
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="rating" className="block text-sm font-medium text-gray-700">Rating</label>
                <div className="flex items-center mt-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                        <StarIcon
                            key={star}
                            className={`h-6 w-6 cursor-pointer ${star <= rating ? 'text-yellow-400' : 'text-gray-300'}`}
                            onClick={() => setRating(star)}
                        />
                    ))}
                </div>
            </div>
            {!isAnonymous && (
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                    <Input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={session?.user?.name || ''}
                    />
                </div>
            )}
            <div className="flex items-center space-x-2">
                <Checkbox 
                    id="anonymous" 
                    checked={isAnonymous}
                    onCheckedChange={setIsAnonymous}
                />
                <label htmlFor="anonymous" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Review as Anonymous User
                </label>
            </div>
            <div>
                <label htmlFor="comment" className="block text-sm font-medium text-gray-700">Comment</label>
                <Textarea
                    id="comment"
                    rows={4}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    required
                />
            </div>
            <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Submitting...' : 'Submit Review'}
            </Button>
        </form>
    )
}
