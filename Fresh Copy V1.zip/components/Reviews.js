import React from 'react'
import ReviewItem from './ReviewItem'

const Reviews = ({ initialReviews = [] }) => {
    return (
        <div className="space-y-4">
            {initialReviews && initialReviews.length === 0 ? (
                <p>No reviews yet.</p>
            ) : (
                initialReviews && initialReviews.map((review, index) => (
                    <ReviewItem key={review.id || index} review={review} />
                ))
            )}
        </div>
    )
}

export default Reviews
