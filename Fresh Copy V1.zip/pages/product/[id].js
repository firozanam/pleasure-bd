import React from 'react';
import Reviews from '../../components/Reviews';

const ProductPage = ({ product, reviews }) => {
  return (
    <div>
      {/* Other product details */}
      <Reviews initialReviews={reviews || []} />
    </div>
  );
};

export async function getServerSideProps(context) {
  const { id } = context.params;
  
  try {
    const product = await fetchProduct(id);
    const reviews = await fetchReviews(id);
    
    return {
      props: {
        product,
        reviews: reviews || [],
      },
    };
  } catch (error) {
    console.error('Error fetching product or reviews:', error);
    return {
      props: {
        product: null,
        reviews: [],
      },
    };
  }
}

export default ProductPage;
