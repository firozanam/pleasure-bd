import { ObjectId } from 'mongodb'
import { getSession } from 'next-auth/react'
import clientPromise from '../../lib/mongodb'

export default async function handler(req, res) {
  const session = await getSession({ req })
  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  let client
  try {
    client = await clientPromise
  } catch (error) {
    console.error('Failed to connect to the database:', error)
    return res.status(500).json({ error: 'Database connection failed' })
  }

  const db = client.db('sample_mflix')

  switch (req.method) {
    case 'POST':
      const { movieId, review, rating } = req.body
      
      if (!movieId || !review || rating === undefined) {
        return res.status(400).json({ error: 'Missing required fields' })
      }

      const newReview = {
        name: session.user.name,
        user_id: session.user.email,
        movie_id: new ObjectId(movieId),
        review,
        rating: parseInt(rating),
        date: new Date(),
      }

      try {
        const result = await db.collection('reviews').insertOne(newReview)
        console.log('Review added successfully:', result.insertedId)
        res.status(201).json({ message: 'Review added successfully', reviewId: result.insertedId })
      } catch (error) {
        console.error('Error adding review:', error)
        res.status(500).json({ error: 'Error adding review', details: error.message })
      }
      break

    default:
      res.setHeader('Allow', ['POST'])
      res.status(405).end(`Method ${req.method} Not Allowed`)
  }
}
