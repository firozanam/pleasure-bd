import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  if (req.method === 'DELETE') {
    const { filename } = req.query;
    if (!filename) {
      return res.status(400).json({ error: 'Filename is required' });
    }

    const filePath = path.join(process.cwd(), 'public', 'images', filename);

    fs.unlink(filePath, (err) => {
      if (err) {
        if (err.code === 'ENOENT') {
          // File doesn't exist, but we'll treat this as a successful deletion
          console.warn(`File not found, but continuing: ${filename}`);
          return res.status(200).json({ message: 'File does not exist or was already deleted' });
        }
        console.error('Error deleting file:', err);
        return res.status(500).json({ error: 'Error deleting file' });
      }

      res.status(200).json({ message: 'File deleted successfully' });
    });
  } else {
    res.setHeader('Allow', ['DELETE']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
