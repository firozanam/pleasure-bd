import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import dbConnect from '@/lib/mongodb'
import Product from '@/models/Product'
import Order from '@/models/Order'

export async function POST(req, { params }) {
    try {
        const session = await getServerSession(authOptions)
        if (!session) {
            return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
        }

        const { rating, comment, name, isAnonymous } = await req.json()

        await dbConnect()
        const product = await Product.findById(params.id)
        if (!product) {
            return NextResponse.json({ error: 'Product not found' }, { status: 404 })
        }

        // Check if the user has purchased the product and if the order status is 'Delivered'
        const order = await Order.findOne({
            'items.id': params.id,
            userId: session.user.id,
            status: 'Delivered'
        })

        if (!order) {
            return NextResponse.json({ error: 'You must purchase and receive the product before submitting a review' }, { status: 403 })
        }

        // Initialize reviews array if it doesn't exist
        if (!product.reviews) {
            product.reviews = [];
        }

        // Check if the user has already submitted a review for this product
        const existingReview = product.reviews.find(review => review.user.toString() === session.user.id)
        if (existingReview) {
            return NextResponse.json({ error: 'You have already submitted a review for this product' }, { status: 400 })
        }

        product.reviews.push({
            user: session.user.id,
            name: isAnonymous ? 'Anonymous' : (name || session.user.name),
            isAnonymous,
            rating,
            comment,
        })

        await product.save()

        return NextResponse.json({ message: 'Review added successfully' })
    } catch (error) {
        console.error('Error adding review:', error)
        return NextResponse.json({ error: 'Server error' }, { status: 500 })
    }
}
